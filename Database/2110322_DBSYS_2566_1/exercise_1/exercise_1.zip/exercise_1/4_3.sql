SELECT order_id, order_date
FROM ordert
WHERE customer_id = 10001;