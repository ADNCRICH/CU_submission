INSERT INTO product
    (product_id,product_description,product_finish,standard_price)
VALUES
    ('7', 'kitchen cabinet', 'Cherry', '1500.00'),
    ('8', 'table', 'Red Oak', '550.00');

SELECT *
FROM product