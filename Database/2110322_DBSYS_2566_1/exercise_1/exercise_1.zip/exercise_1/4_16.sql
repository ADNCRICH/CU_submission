UPDATE product
SET standard_price = 5400
WHERE product_description = 'Sofabed';

SELECT *
FROM product;